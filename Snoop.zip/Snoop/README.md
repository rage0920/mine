## Note: It's a experimental project.
# Changes 

- Added random stride option, by using this option, the program run indefinitely after the end of keyspace, it starts again from starting range with the updated random stride of given bit length, it continues doing this until it found keys or you stoped it. This is like a random walk with random distance.
- For --rstride N, N should be ```128 >= N >= 1```, here N is the bit length of the incrementor.
- Added support for XPoint search mode.
- Saving-Loading checkpoints are not modified for new changes.
- OpenCL support removed.
- Everything else is same as original Snoop.
  
# Usage

- For XPoint mode use x point of the public key, without ```02``` or ```03``` prefix(64 chars).
- Don't use XPoint mode with 'uncompressed' compression type.
- Address or XPoint file should be in text format with one address or xpoint per line.

```
Snoop.exe --help
Snoop OPTIONS [TARGETS]
Where TARGETS is one or more addresses

--help                       Display this message
-c, --compressed             Use compressed points
-u, --uncompressed           Use Uncompressed points
--compression  MODE          Specify compression where MODE is
                                 COMPRESSED or UNCOMPRESSED or BOTH
-d, --device ID              Use device ID
-b, --blocks N               N blocks
-t, --threads N              N threads per block
-p, --points N               N points per thread
-i, --in FILE                Read addresses from FILE, one per line
-o, --out FILE               Write keys to FILE
-f, --follow                 Follow text output
-m, --mode MODE              Specify search mode where MODE is
                                 ADDRESS or XPOINT
--list-devices               List available devices
--keyspace KEYSPACE          Specify the keyspace:
                                 START:END
                                 START:+COUNT
                                 START
                                 :END
                                 :+COUNT
                             Where START, END, COUNT are in hex format
--stride N                   Increment by N keys at a time
--rstride N                  Random stride bits[1 to 128], continue after end of range by setting up new random stride
--share M/N                  Divide the keyspace into N equal shares, process the Mth share
--continue FILE              Save/load progress from FILE
-v, --version                Show version
```


```
Snoop.exe -b 64 -t 256 -p 1024  -m xpoint --keyspace 1:1ffffffffffffffff B3E772216695845FA9DDA419FB5DACA28154D8AA59EA302F05E916635E47B9F6
[2022-02-09.21:36:04] [Info] Compression : compressed
[2022-02-09.21:36:04] [Info] Starting at : 1 (1 bit)
[2022-02-09.21:36:04] [Info] Ending at   : 1BFFFFFFFF  (37 bit)
[2022-02-09.21:36:04] [Info] Range       : 1BFFFFFFFF  (37 bit)
[2022-02-09.21:36:04] [Info] Initializing GeForce GTX 1650
[2022-02-09.21:36:04] [Info] Generating 16,777,216 starting points (640.0MB)
[2022-02-09.21:36:09] [Info] 10.0%  20.0%  30.0%  40.0%  50.0%  60.0%  70.0%  80.0%  90.0%  100.0%
[2022-02-09.21:36:11] [Info] Done
[2022-02-09.21:36:25] [Info] Found key for address '1Be2UF9NLfyLFbtm3TCbmuocc9N1Kduci1'. Written to 'Found.txt'
[2022-02-09.21:36:25] [Info] Address     : 1Be2UF9NLfyLFbtm3TCbmuocc9N1Kduci1
                             Private key : 9DE820A7C
                             Compressed  : yes
                             Public key  : 02B3E772216695845FA9DDA419FB5DACA28154D8AA59EA302F05E916635E47B9F6






# Building
### Windows
- Microsoft Visual Studio Community 2019
- CUDA version 10.0
## Linux
- Install libgmp: ```sudo apt install -y libgmp-dev```

- Edit the makefile and set up the appropriate CUDA SDK and compiler paths for nvcc.

    ```make
    CUDA       = /usr/local/cuda-11.0
    CXXCUDA    = /usr/bin/g++
    ```
 - To build with CUDA: pass CCAP value according to your GPU compute capability
    ```sh
    $ cd Snoop
    $ make CCAP=75 all
    ```
